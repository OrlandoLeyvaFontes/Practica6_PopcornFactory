package com.example.popcornfactory

data class Cliente(var nombre : String, var tipoPago: String, var asiento: Int) {
}